<?php

/**
 * Created by PhpStorm.
 * User: Sebastian Kubalski
 * Date: 25.12.2015
 * Time: 22:09
 */

namespace App\Exceptions;

use Exception;
class CustomException extends Exception{}