<?php

/**
 * Created by PhpStorm.
 * User: Sebastian Kubalski
 * Date: 25.12.2015
 * Time: 21:55
 */

namespace App\Exceptions;
class DateBaseDMLException extends CustomDateBaseException
{

}