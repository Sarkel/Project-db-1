<?php

/**
 * Created by PhpStorm.
 * User: Sebastian Kubalski
 * Date: 25.12.2015
 * Time: 22:07
 */

namespace App\Exceptions;

use PDOException;
abstract class CustomDateBaseException extends PDOException
{

}